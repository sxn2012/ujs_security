Images in this folder will automatically be deleted
before the tests start